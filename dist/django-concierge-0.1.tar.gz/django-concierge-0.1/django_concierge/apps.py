from django.apps import AppConfig


class DjangoConciergeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "django_concierge"
    label = "concierge"
